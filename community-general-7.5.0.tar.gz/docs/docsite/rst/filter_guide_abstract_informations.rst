..
  Copyright (c) Ansible Project
  GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
  SPDX-License-Identifier: GPL-3.0-or-later

Abstract transformations
------------------------

.. toctree::
   :maxdepth: 1

   filter_guide_abstract_informations_dictionaries
   filter_guide_abstract_informations_grouping
   filter_guide_abstract_informations_merging_lists_of_dictionaries
   filter_guide_abstract_informations_counting_elements_in_sequence
